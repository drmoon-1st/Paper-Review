# Identification of Deep Network Generated Images Using Disparities in Color Components

---

## Abstract

- Deep Network Generated(DNG) 이미지를 구분하는 방법을 제안함.
- DNG 이미지와 진짜 이미지 간의 차이를 각 color components에 따라 구함.
- DNG 이미지를 식별하기 위해 color 이미지 통계를 캡쳐하는 feature set를 제안함.
- 또한 본 논문에서는 training-testing data가 이미지 source나 생성 모델, 진짜 이미지만으로의 detection에서 match 되었나 mismatch 되었나와 같은 몇몇 detection situation을 평가함.
- GAN 모델이 무엇인지 알 수 없을 때에 좋은 성능을 뽑아냄.

## Introduction

GAN이 등장하며 머신러닝 기법을 적용해 생성된 이미지들의 퀄리티가 매우 높아졌으며, 진짜 이미지와 생성된 이미지의 구분이 쉽지 않아졌다. 이를 통해 가짜 뉴스 등이 만들어지기도 한다. 따라서 많은 딥페이크 문제들이 대두되었다.

본 논문에서는 카메라 이미징과 DNG 이미지의 차이를 고려해, 두 이미지 간의 상이 함을 확인하였고 색차 성분의 residual domain에서 더욱 구분이 쉽다는 것을 분석하였다. 

따라서 본 논문의 contribution을 요약하자면

- DNG 이미지들은 카메라 이미징과 차이가 있기에 그 두 이미지간의 격차를 나타내고 분석하였다. 몇몇 color space의 adjacent pixels 사이의 correlation을 측정하여 두 이미지의 통계적 속성이 HSV 및 YCbCr color space간의 색차 구성 요소에서 차이가 난다는 것을 찾아내었다(차이는 residual domain에서 더 뚜렷함).
- 본 논문에서는 DNG 이미지 identification의 효과적인 feature set을 제안하였다. Feature set은 여러 color component의 residual 이미지에서 뽑아낸 co-occurrence matrices를 포함한다. 이는 차원이 낮고, 적은 training set으로도 좋은 성능을 발휘한다.
- 본 논문에서 다양한 detection 시나리오에서의 identification performance를 평가하였다. 제안된 method는 기존의 method와 비교하여 볼 때에 좋은 성능을 보였다. 특히 GAN 모델을 알 수 없을 경우에도 좋은 결과를 뽑아내었다.

## DNG Image Identification

### Analysis from the Perspective of Color

**The generation pipeline DNG images**

DNG 이미지를 진짜 이미지와 구분하기 위해서는 GAN이 이미지를 생성하고 남은 결함을 찾아야 한다. GAN 모델 중 생성자의 마지막 layer에서, 몇몇 feature map이 3-channel(R, G, B)의 tensor으로 변화한다. 이 과정에서 convolution operation이 DNG 이미지에  고유 속성을 입힌다. 반면 카메라로 찍은 진짜 이미지의 pixel은 본질적으로 다른 방식으로 correlated 되어야 한다. 즉 진짜 이미지와 DNG 이미지는 본질적으로 다를 수 있다는 것이다.

**Discernibility of color component** 

GAN은 이미지를 RGB 공간에서 생성하기에 다른 color space의 properties에는 주의를 덜 기울이게 된다. 따라서 본 논문에서는 이미지를 RGB, HSW, YCbCr 등의 공간에서 분석하였다. 또한 어떤 color component가 DNG 이미지를 구분하는데 효과적인지 실험하는 metric을 사용하였다.

(a)

![Untitled](Identification%20of%20Deep%20Network%20Generated%20Images%20Us%20fcaad5d5454549a6885d581443436166/Untitled.png)

- $i$ 번째 이미지인 $I$ 일 때, 본 논문에서는 color component $I^c$ 인접한 pixel 사이의 상관계수를 계산한다$(c\in \{R,G,B,H,S,V,Y,Cb,Cr\})$.
- $\bar{I^c}$ 는 $I^c$ 의 평균값이다.
- m, n 은 이미지의 height와 width이다.
- $r^c_i$ 는  인접한 pixel 값들의 연관성을 나타낸다. 즉, 이 값이 크면 클수록 $I^c$ 의 인접한 pixel 값들의 correlation이 높다는 것이다.
- 다만 분석을 간소화하기 위해 horizontal 인접 pixel에 관해 분석하였다.

(b)

![Untitled](Identification%20of%20Deep%20Network%20Generated%20Images%20Us%20fcaad5d5454549a6885d581443436166/Untitled%201.png)

- 본 논문은 DNG 이미지의 set에서, 각 이미지당 $r^c_i$ 를 계산하고 $r^c_i$ 의 히스토그램인 $H^c_{DNG}$ 를 구축한다.
- $H^c_{Real}$ : 진짜 이미지의 히스토그램
- Chi-square distance를 통해 두 히스토그램의 유사도를 판단한다.
- $x$ : bin index
- $d_{x^2}(H^c_{DNG},H^c_{Real})$ : 식별 가능 metric. 이 값이 커질수록 DNG 이미지와 진짜 이미지의 식별가능성이 더욱 명확해진다.

본 논문의 저자들은 대량의 이미지를 생성해 그 중 10000장의 가짜 이미지를 골라내었다. 그 후, 진짜 이미지와 생성된 이미지들의 히스토그램을 구축한다. RGB channels에서는 진짜와 생성된 이미지들의 겹치지 않는 영역이 적었다. 바꾸어 말하자면, 원본 이미지와 생성된 이미지의 격차가 RGB 공간에서는 명확하지 않았다는 것이며, RGB channel들이 진짜 이미지의 분포와 유사하게 생성되었다는 것이다.

RGB 공간에서 HSV/YCbCr 공간으로의 변환을 시킨다면, RGB channel들은 다른 color channel을 만들기 위해 linear, non-linear한 combination으로 merge된다. 이 방법을 통해, DNG 이미지와 실재 이미지의 격차가 더욱 증폭될 것이며, 진짜 이미지와 DNG 이미지의 히스토그램 겹치지 않는 영역 이 커질 것이다. 실험을 통해 본 결과로는 색차 구성요소가 다른 구성요소보다 더 식별 가능하다는 것을 알 수 있다.

**discernibility analysis in first-order differential residual domain**

![Untitled](Identification%20of%20Deep%20Network%20Generated%20Images%20Us%20fcaad5d5454549a6885d581443436166/Untitled%202.png)

DNG 이미지와 진짜 이미지의 content는 항상 구분가능하지 않다. 즉, 두 이미지의 content가 비슷하다는 것이다. 이는 두 이미지의 격차를 구분하는 것에 부정적인 영향을 미칠 수 있다. 따라서 high-pass filtering을 적용해 이미지의 content를 억제한 후 이미지 residual의 차이를 조사하는 것이 합리적이다. 본 논문에서는 1차 미분 operator을 예로 적용해 이미지의 residual을 구하였다.

![Untitled](Identification%20of%20Deep%20Network%20Generated%20Images%20Us%20fcaad5d5454549a6885d581443436166/Untitled%203.png)

- $I^c$ : 이미지 $I$ 의  c 번째  구성요소
- $R^c$ : $I$ 에 대응되는 residual
- 본 논문에서는 horizontal 차이만 고려
- residual domain에 이미지 residual이 있으면 첫 번째 식의 $I^c$ 와 $R^c$ 를 $\bar{I^c}$ 과 $\bar{R^c}$ 로 대체한다. 그 후 식별성 분석을 진행한다.

![Untitled](Identification%20of%20Deep%20Network%20Generated%20Images%20Us%20fcaad5d5454549a6885d581443436166/Untitled%204.png)

상기된 그림에서 DNG 이미지와 진짜 이미지의 겹치지 않는 부분이 더욱 눈에 띄는 것을 확인할 수 있다. 즉, 두 이미지는 residual domain에서 더욱 구분하기가 용이하다는 것이다. 이 현상은 DNG 이미지는 진짜 이미지와 다른 처리 pipeline을 거쳐 DNG 이미지의 통계가 residual domain에서 다르게 나타난다고 볼 수 있다. 게다가 spatial domain에서 얻은 관측값은 residual domain에서도 유지된다.

1. H, S, Cb, Cr의 DNG 이미지와 진짜 이미지의 겹치지 않는 영역은 R, G, B, V, Y의 영역보다 크다.
2. 4개의 색차 성분의 식별 metric는 다른 성분의 metric 값 보다 크다.

즉, residual domain에서 뽑아낸 몇몇 색차 성분은 DNG 이미지를 구분하는데 사용될 수 있다는 것이다.

### Extracting Features from Color Components

앞선 분석에 기반해 본 논문에서는 residual domain의 색차 성분에서 feature을 추출하였다. 이미지가 주어지면 색 성분에서 feature을 연산한다. 그 후, 그 결과값들을 모두 feature vector으로 concatenate한다. 마지막으로 이 이미지가 진짜인지 가짜인지 판별하는 classifier을 학습시킨다.

Feature extraction 단계에서는 이미지의 1차 미분 operator을 통해 이

**Truncating image residuals**

1차 미분 operator을 통해 H,S, Cb, Cr component의 residual이 구해지면, co-occurrence matrix를 계산하기 전에 residual을 전처리 해야한다. 왜냐하면 residual에는 너무나도 많은 distinct element가 있기 때문이다(이는 matrix의 차원이 커질 수 있음을 의미한다). distinct element의 수를 줄이기 위해 residual 이미지인 $R^c$ 에 다음과 같은 처리를 해준다.

![Untitled](Identification%20of%20Deep%20Network%20Generated%20Images%20Us%20fcaad5d5454549a6885d581443436166/Untitled%205.png)

- $(x,y)$ : residual 내 Element의 위치 index
- Truncation threshold : $r>0$
- 즉, 이 과정을 거치고 난다면 $R^c$ 의 값들은 $[-r, r]$ 의 범위(정수)를 가지게 된다.

**Extracting co-occurrence features**

최종적으로 $\breve{R}^H,\breve{R}^S,\breve{R}^{Cb},\breve{R}^{Cr}$ 4개의 co-occurrence matrices가 만들어진다. 2-D array $V$ 의 co-occurrence matrix는 다음과 같이 연산된다.

![Untitled](Identification%20of%20Deep%20Network%20Generated%20Images%20Us%20fcaad5d5454549a6885d581443436166/Untitled%206.png)

- $1(\cdot)$ : Indicator function
- $(\theta_1,\theta_2,...,\theta_d)$ : Index of co-occurrence matrix
- $d$ : Co-occurrence matrix의 순서
- $n$ : Normalization factor
- $\bigtriangleup{x},\bigtriangleup{y}$ : 2개의 이웃된 element의 offset
- 각 co-occurrence matrix인 $\breve{R}^c$ 의 차원은 $(2\tau+1)^d$ 이다.

Co-occurrence matrix가 대칭이기 때문에 feature 차원을 2개의 bin$\{C(\theta_1,\theta_2,...,\theta_d),C(\theta_d,\theta_{d-1},...,\theta_1)\}$ 을 하나로 합쳐 줄일 수 있다. 합친 후의 차원은 $(2\tau+1)^d+(2\tau+1)^{d-1})/2$ 이 된다(학습 속도도 빨리진다).

**Practical implementation**

본 논문의 구현에서는 이미지의 residual을 얻기 위한 horizontal, vertical direction으로 작동하는 2개의 1차 미분 operator을 사용한다. 본 논문의 구현은 다음과 같은 파라미터를 가진다.

- truncation threshold $\tau=2$
- $d=3$
- $\bigtriangleup{x},\bigtriangleup{y}\in \{(0,1),(1,0)\}$

### Detection Scenarios and Strategies

세상에는 여러 Generative model이 존재한다. 또한 그들은 여러 데이터셋을 사용해 학습되고, 이미지를 생성한다. 결국, DNG 이미지는 점점 진짜 이미지와 구분하기 어려워지고 있다는 것이다. 따라서 본 논문에서는 detection 시나리오를 3개의 cases로 나누어 하기된 detection을 진행한다.

**Matched training-testing data**

이 케이스에서 training/testing DNG 이미지는 동일한 진짜 이미지로 학습된 하나의 모델에서 생성된다. Detection을 진행하기 위해, investigator은 진짜 이미지와 DNG 이미지를 활용해 binary classifier을 학습시켜 사용한다.

**Mismatched training-testing data**

 이 케이스에서 training/testing DNG 이미지는 다른 source로부터 생성된다. 이러한 mismatched source 때문에, 이 사례는 detection method의 일반화 능력을 평가하는데 사용될 수 있다. 즉, 이 결과가 좋을수록 실제 상황에서 판별을 잘 진행할 확률이 높다는 것이다.

**Model-unaware case**

DNG 이미지가 어떤 모델에서 생성되었는지 알 수 없는 경우가 종종 있다. 이러한 case를 해결하기 위해 사용할만한 방법으로는 one-class classifier을 진짜 이미지로만 학습시키고, testing 이미지가 진짜인지 가짜인지 판별하는 것이 있다.

[HSV](https://www.notion.so/HSV-dd8c1a70a84a462c90c479e2e6c29608)

[YCbCr](https://www.notion.so/YCbCr-39f8719111df47aa8400160d76539a12)